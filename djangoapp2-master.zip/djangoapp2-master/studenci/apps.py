from django.apps import AppConfig


class StudenciConfig(AppConfig):
    name = 'studenci'
